#to build the image 
#docker build .

#to list the images
#docker images

#to add a tag to the image
#docker-compose build

#to create a container
#docker-compose up

#See the running containers
#docker-compose ps
