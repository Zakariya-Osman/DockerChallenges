#to build the image 
#docker build .

#to list the images
#docker images

#to add a tag to the image
#docker build -t <repository name> <file path>
#example: docker build -t challenge-1 .

#create a container
#docker run -d -p <port:port> <image id>
    #p is for port
    #d is for deamon
#example: docker run -d -p 80:80 8b0a2c43a149

#See the running containers
#docker ps

#stop a container
#docker stop <container id> or <container name>
#example: docker stop 8b0a2c43a149
#example: docker stop wonderful_dirac

#this will show the stopped containers
#docker ps -a

#to remove a container
#docker rm <container id> or <container name>

#to remove an image
#docker rmi <image id> or <image name>